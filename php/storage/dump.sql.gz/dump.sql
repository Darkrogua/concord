-- Adminer 5.4.2 PostgreSQL 16.10 dump

DROP TABLE IF EXISTS "backend_access_log";
DROP SEQUENCE IF EXISTS "public".backend_access_log_id_seq;
CREATE SEQUENCE "public".backend_access_log_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."backend_access_log" (
    "id" integer DEFAULT nextval('backend_access_log_id_seq') NOT NULL,
    "user_id" integer NOT NULL,
    "ip_address" character varying(255),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "backend_access_log_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "backend_user_groups";
DROP SEQUENCE IF EXISTS "public".backend_user_groups_id_seq;
CREATE SEQUENCE "public".backend_user_groups_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."backend_user_groups" (
    "id" integer DEFAULT nextval('backend_user_groups_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "code" character varying(255),
    "description" text,
    "is_new_user_default" boolean DEFAULT false NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "backend_user_groups_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX name_unique ON public.backend_user_groups USING btree (name);

CREATE INDEX code_index ON public.backend_user_groups USING btree (code);


DROP TABLE IF EXISTS "backend_user_preferences";
DROP SEQUENCE IF EXISTS "public".backend_user_preferences_id_seq;
CREATE SEQUENCE "public".backend_user_preferences_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."backend_user_preferences" (
    "id" integer DEFAULT nextval('backend_user_preferences_id_seq') NOT NULL,
    "user_id" integer NOT NULL,
    "namespace" character varying(100) NOT NULL,
    "group" character varying(50) NOT NULL,
    "item" character varying(150) NOT NULL,
    "value" text,
    "site_id" integer,
    "site_root_id" integer,
    CONSTRAINT "backend_user_preferences_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX user_item_index ON public.backend_user_preferences USING btree (user_id, namespace, "group", item);

INSERT INTO "backend_user_preferences" ("id", "user_id", "namespace", "group", "item", "value", "site_id", "site_root_id") VALUES
(1,	1,	'backend',	'hints',	'hidden',	'{"builder-version-rollback":1}',	NULL,	NULL);

DROP TABLE IF EXISTS "backend_user_roles";
DROP SEQUENCE IF EXISTS "public".backend_user_roles_id_seq;
CREATE SEQUENCE "public".backend_user_roles_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."backend_user_roles" (
    "id" integer DEFAULT nextval('backend_user_roles_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "code" character varying(255),
    "color_background" character varying(255),
    "description" text,
    "permissions" text,
    "is_system" boolean DEFAULT false NOT NULL,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "backend_user_roles_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX role_unique ON public.backend_user_roles USING btree (name);

CREATE INDEX role_code_index ON public.backend_user_roles USING btree (code);


DROP TABLE IF EXISTS "backend_user_throttle";
DROP SEQUENCE IF EXISTS "public".backend_user_throttle_id_seq;
CREATE SEQUENCE "public".backend_user_throttle_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."backend_user_throttle" (
    "id" integer DEFAULT nextval('backend_user_throttle_id_seq') NOT NULL,
    "user_id" integer,
    "ip_address" character varying(255),
    "attempts" integer DEFAULT '0' NOT NULL,
    "last_attempt_at" timestamp(0),
    "is_suspended" boolean DEFAULT false NOT NULL,
    "suspended_at" timestamp(0),
    "is_banned" boolean DEFAULT false NOT NULL,
    "banned_at" timestamp(0),
    CONSTRAINT "backend_user_throttle_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX backend_user_throttle_user_id_index ON public.backend_user_throttle USING btree (user_id);

CREATE INDEX backend_user_throttle_ip_address_index ON public.backend_user_throttle USING btree (ip_address);

INSERT INTO "backend_user_throttle" ("id", "user_id", "ip_address", "attempts", "last_attempt_at", "is_suspended", "suspended_at", "is_banned", "banned_at") VALUES
(1,	1,	'172.18.0.2',	0,	NULL,	'0',	NULL,	'0',	NULL);

DROP TABLE IF EXISTS "backend_users";
DROP SEQUENCE IF EXISTS "public".backend_users_id_seq;
CREATE SEQUENCE "public".backend_users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."backend_users" (
    "id" integer DEFAULT nextval('backend_users_id_seq') NOT NULL,
    "first_name" character varying(255),
    "last_name" character varying(255),
    "login" character varying(255) NOT NULL,
    "email" character varying(255) NOT NULL,
    "password" character varying(255) NOT NULL,
    "activation_code" character varying(255),
    "persist_code" character varying(255),
    "reset_password_code" character varying(255),
    "permissions" text,
    "is_activated" boolean DEFAULT false NOT NULL,
    "is_superuser" boolean DEFAULT false NOT NULL,
    "activated_at" timestamp(0),
    "last_login" timestamp(0),
    "deleted_at" timestamp(0),
    "role_id" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "is_password_expired" boolean DEFAULT false NOT NULL,
    "password_changed_at" timestamp(0),
    CONSTRAINT "backend_users_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX login_unique ON public.backend_users USING btree (login);

CREATE UNIQUE INDEX email_unique ON public.backend_users USING btree (email);

CREATE INDEX act_code_index ON public.backend_users USING btree (activation_code);

CREATE INDEX reset_code_index ON public.backend_users USING btree (reset_password_code);

CREATE INDEX admin_role_index ON public.backend_users USING btree (role_id);

INSERT INTO "backend_users" ("id", "first_name", "last_name", "login", "email", "password", "activation_code", "persist_code", "reset_password_code", "permissions", "is_activated", "is_superuser", "activated_at", "last_login", "deleted_at", "role_id", "created_at", "updated_at", "is_password_expired", "password_changed_at") VALUES
(1,	'Al',	'Blaze',	'zen',	'zen@8ber.ru',	'$2y$10$FPEaH0XpP0DNKi2ZuqrDlOwuHG9tCokLPCqpo3LHnIPdU8eYeaDIC',	NULL,	'$2y$10$YQGzXuDJLWRPxVucbgFcP.ixIT22YMF/sEo.g05NwjMyZhs5Ln4bK',	NULL,	'',	'1',	'1',	NULL,	'2026-04-28 19:22:04',	NULL,	NULL,	'2026-04-28 19:22:04',	'2026-04-28 19:22:04',	'0',	'2026-04-28 19:22:04');

DROP TABLE IF EXISTS "backend_users_groups";
CREATE TABLE "public"."backend_users_groups" (
    "user_id" integer NOT NULL,
    "user_group_id" integer NOT NULL,
    CONSTRAINT "backend_users_groups_pkey" PRIMARY KEY ("user_id", "user_group_id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "cache";
CREATE TABLE "public"."cache" (
    "key" character varying(255) NOT NULL,
    "value" text NOT NULL,
    "expiration" integer NOT NULL
)
WITH (oids = false);

CREATE UNIQUE INDEX cache_key_unique ON public.cache USING btree (key);


DROP TABLE IF EXISTS "cms_theme_data";
DROP SEQUENCE IF EXISTS "public".cms_theme_data_id_seq;
CREATE SEQUENCE "public".cms_theme_data_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."cms_theme_data" (
    "id" integer DEFAULT nextval('cms_theme_data_id_seq') NOT NULL,
    "theme" character varying(255),
    "data" text,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "cms_theme_data_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX cms_theme_data_theme_index ON public.cms_theme_data USING btree (theme);


DROP TABLE IF EXISTS "cms_theme_logs";
DROP SEQUENCE IF EXISTS "public".cms_theme_logs_id_seq;
CREATE SEQUENCE "public".cms_theme_logs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."cms_theme_logs" (
    "id" integer DEFAULT nextval('cms_theme_logs_id_seq') NOT NULL,
    "type" character varying(20) NOT NULL,
    "theme" character varying(255),
    "template" character varying(255),
    "old_template" character varying(255),
    "content" text,
    "old_content" text,
    "user_id" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "cms_theme_logs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX cms_theme_logs_type_index ON public.cms_theme_logs USING btree (type);

CREATE INDEX cms_theme_logs_theme_index ON public.cms_theme_logs USING btree (theme);

CREATE INDEX cms_theme_logs_user_id_index ON public.cms_theme_logs USING btree (user_id);


DROP TABLE IF EXISTS "cms_theme_templates";
DROP SEQUENCE IF EXISTS "public".cms_theme_templates_id_seq;
CREATE SEQUENCE "public".cms_theme_templates_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."cms_theme_templates" (
    "id" integer DEFAULT nextval('cms_theme_templates_id_seq') NOT NULL,
    "source" character varying(255) NOT NULL,
    "path" character varying(255) NOT NULL,
    "content" text NOT NULL,
    "file_size" integer NOT NULL,
    "updated_at" timestamp(0),
    "deleted_at" timestamp(0),
    CONSTRAINT "cms_theme_templates_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX cms_theme_templates_source_index ON public.cms_theme_templates USING btree (source);

CREATE INDEX cms_theme_templates_path_index ON public.cms_theme_templates USING btree (path);


DROP TABLE IF EXISTS "dashboard_dashboards";
DROP SEQUENCE IF EXISTS "public".dashboard_dashboards_id_seq;
CREATE SEQUENCE "public".dashboard_dashboards_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."dashboard_dashboards" (
    "id" bigint DEFAULT nextval('dashboard_dashboards_id_seq') NOT NULL,
    "name" character varying(255),
    "code" character varying(255),
    "icon" character varying(255),
    "owner_type" character varying(255),
    "owner_field" character varying(255),
    "definition" text,
    "is_custom" boolean DEFAULT false NOT NULL,
    "is_global" boolean DEFAULT false NOT NULL,
    "sort_order" integer,
    "updated_user_id" bigint,
    "created_user_id" bigint,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "is_interval_hidden" boolean DEFAULT false NOT NULL,
    "is_system" boolean DEFAULT false NOT NULL,
    "is_hidden" boolean DEFAULT false NOT NULL,
    CONSTRAINT "dashboard_dashboards_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "dashboard_dashboards" ("id", "name", "code", "icon", "owner_type", "owner_field", "definition", "is_custom", "is_global", "sort_order", "updated_user_id", "created_user_id", "created_at", "updated_at", "is_interval_hidden", "is_system", "is_hidden") VALUES
(1,	'System Dashboard',	'system',	'ph ph-globe',	'Dashboard\Controllers\Index',	'system',	NULL,	'0',	'1',	1,	1,	1,	'2026-04-28 19:24:35',	'2026-04-28 19:24:35',	'0',	'1',	'0');

DROP TABLE IF EXISTS "dashboard_dashboards_roles";
CREATE TABLE "public"."dashboard_dashboards_roles" (
    "dashboard_id" bigint NOT NULL,
    "role_id" integer NOT NULL,
    CONSTRAINT "dashboard_dashboards_roles_pkey" PRIMARY KEY ("dashboard_id", "role_id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "dashboard_report_data_cache";
DROP SEQUENCE IF EXISTS "public".dashboard_report_data_cache_id_seq;
CREATE SEQUENCE "public".dashboard_report_data_cache_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."dashboard_report_data_cache" (
    "id" integer DEFAULT nextval('dashboard_report_data_cache_id_seq') NOT NULL,
    "key" character varying(255) NOT NULL,
    "value" text NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "value_date" date NOT NULL,
    CONSTRAINT "dashboard_report_data_cache_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX dashboard_report_data_cache_created_at_index ON public.dashboard_report_data_cache USING btree (created_at);

CREATE INDEX dashboard_report_data_cache_key_value_date_index ON public.dashboard_report_data_cache USING btree (key, value_date);

CREATE INDEX dashboard_report_data_cache_key_index ON public.dashboard_report_data_cache USING btree (key);


DROP TABLE IF EXISTS "dashboard_traffic_stats_pageviews";
DROP SEQUENCE IF EXISTS "public".dashboard_traffic_stats_pageviews_id_seq;
CREATE SEQUENCE "public".dashboard_traffic_stats_pageviews_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."dashboard_traffic_stats_pageviews" (
    "id" bigint DEFAULT nextval('dashboard_traffic_stats_pageviews_id_seq') NOT NULL,
    "ev_datetime" timestamp(0),
    "ev_date" date,
    "ev_year_month_day" character varying(10),
    "ev_year_month" character varying(10),
    "ev_year_quarter" character varying(10),
    "ev_year_week" character varying(10),
    "ev_year" character varying(10),
    "ev_timestamp" timestamp(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "user_authenticated" boolean,
    "client_id" character varying(64),
    "first_time_visit" boolean DEFAULT false NOT NULL,
    "user_agent" character varying(255),
    "page_path" character varying(255),
    "ip" character varying(255),
    "city" character varying(64),
    "country" character varying(64),
    "referral_domain" character varying(255),
    "site_id" integer,
    CONSTRAINT "dashboard_traffic_stats_pageviews_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_datetime_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_datetime);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_date_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_date);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_year_month_day_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_year_month_day);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_year_month_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_year_month);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_year_quarter_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_year_quarter);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_year_week_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_year_week);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_year_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_year);

CREATE INDEX dashboard_traffic_stats_pageviews_ev_timestamp_index ON public.dashboard_traffic_stats_pageviews USING btree (ev_timestamp);

CREATE INDEX dashboard_traffic_stats_pageviews_user_authenticated_index ON public.dashboard_traffic_stats_pageviews USING btree (user_authenticated);

CREATE INDEX dashboard_traffic_stats_pageviews_client_id_index ON public.dashboard_traffic_stats_pageviews USING btree (client_id);

CREATE INDEX dashboard_traffic_stats_pageviews_first_time_visit_index ON public.dashboard_traffic_stats_pageviews USING btree (first_time_visit);

CREATE INDEX dashboard_traffic_stats_pageviews_user_agent_index ON public.dashboard_traffic_stats_pageviews USING btree (user_agent);

CREATE INDEX dashboard_traffic_stats_pageviews_page_path_index ON public.dashboard_traffic_stats_pageviews USING btree (page_path);

CREATE INDEX dashboard_traffic_stats_pageviews_city_index ON public.dashboard_traffic_stats_pageviews USING btree (city);

CREATE INDEX dashboard_traffic_stats_pageviews_country_index ON public.dashboard_traffic_stats_pageviews USING btree (country);

CREATE INDEX dashboard_traffic_stats_pageviews_referral_domain_index ON public.dashboard_traffic_stats_pageviews USING btree (referral_domain);

CREATE INDEX dashboard_traffic_stats_pageviews_site_id_index ON public.dashboard_traffic_stats_pageviews USING btree (site_id);


DROP TABLE IF EXISTS "deferred_bindings";
DROP SEQUENCE IF EXISTS "public".deferred_bindings_id_seq;
CREATE SEQUENCE "public".deferred_bindings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."deferred_bindings" (
    "id" integer DEFAULT nextval('deferred_bindings_id_seq') NOT NULL,
    "master_type" character varying(255) NOT NULL,
    "master_field" character varying(255) NOT NULL,
    "slave_type" character varying(255) NOT NULL,
    "slave_id" integer NOT NULL,
    "session_key" character varying(255) NOT NULL,
    "pivot_data" text,
    "is_bind" boolean DEFAULT true NOT NULL,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "deferred_bindings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "failed_jobs";
DROP SEQUENCE IF EXISTS "public".failed_jobs_id_seq;
CREATE SEQUENCE "public".failed_jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."failed_jobs" (
    "id" integer DEFAULT nextval('failed_jobs_id_seq') NOT NULL,
    "uuid" character varying(255),
    "connection" text NOT NULL,
    "queue" text NOT NULL,
    "payload" text NOT NULL,
    "exception" text,
    "failed_at" timestamp(0),
    CONSTRAINT "failed_jobs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX failed_jobs_uuid_unique ON public.failed_jobs USING btree (uuid);


DROP TABLE IF EXISTS "jobs";
DROP SEQUENCE IF EXISTS "public".jobs_id_seq;
CREATE SEQUENCE "public".jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."jobs" (
    "id" bigint DEFAULT nextval('jobs_id_seq') NOT NULL,
    "queue" character varying(255) NOT NULL,
    "payload" text NOT NULL,
    "attempts" smallint NOT NULL,
    "reserved_at" integer,
    "available_at" integer NOT NULL,
    "created_at" integer NOT NULL,
    CONSTRAINT "jobs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX jobs_queue_reserved_at_index ON public.jobs USING btree (queue, reserved_at);


DROP TABLE IF EXISTS "migrations";
DROP SEQUENCE IF EXISTS "public".migrations_id_seq;
CREATE SEQUENCE "public".migrations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."migrations" (
    "id" integer DEFAULT nextval('migrations_id_seq') NOT NULL,
    "migration" character varying(255) NOT NULL,
    "batch" integer NOT NULL,
    CONSTRAINT "migrations_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "migrations" ("id", "migration", "batch") VALUES
(1,	'2013_10_01_000001_Db_Deferred_Bindings',	1),
(2,	'2013_10_01_000002_Db_System_Files',	1),
(3,	'2013_10_01_000003_Db_System_Plugin_Versions',	1),
(4,	'2013_10_01_000004_Db_System_Plugin_History',	1),
(5,	'2013_10_01_000005_Db_System_Settings',	1),
(6,	'2013_10_01_000006_Db_System_Parameters',	1),
(7,	'2013_10_01_000008_Db_System_Mail_Templates',	1),
(8,	'2013_10_01_000009_Db_System_Mail_Layouts',	1),
(9,	'2014_10_01_000010_Db_Jobs',	1),
(10,	'2014_10_01_000011_Db_System_Event_Logs',	1),
(11,	'2014_10_01_000012_Db_System_Request_Logs',	1),
(12,	'2014_10_01_000013_Db_System_Sessions',	1),
(13,	'2015_10_01_000016_Db_Cache',	1),
(14,	'2015_10_01_000017_Db_System_Revisions',	1),
(15,	'2015_10_01_000018_Db_FailedJobs',	1),
(16,	'2017_10_01_000023_Db_System_Mail_Partials',	1),
(17,	'2021_10_01_000025_Db_Add_Pivot_Data_To_Deferred_Bindings',	1),
(18,	'2022_10_01_000026_Db_System_Site_Definitions',	1),
(19,	'2023_10_01_000027_Db_Add_Site_To_Settings',	1),
(20,	'2023_10_01_000028_Db_Add_Restrict_Roles_To_Sites',	1),
(21,	'2023_10_01_000029_Db_System_Site_Groups',	1),
(22,	'2023_10_01_000030_Db_Add_Group_To_Sites',	1),
(23,	'2024_10_01_000031_Db_Add_Sort_Order_To_Deferred_Bindings',	1),
(24,	'2024_10_01_000032_Db_Add_Fallback_Locale_To_Sites',	1),
(25,	'2026_10_01_000033_Db_System_Translate_Attributes',	1),
(26,	'2026_10_01_000034_Db_Add_Site_Group_To_Settings',	1),
(27,	'2026_10_01_000035_Db_System_Plugin_Site_Groups',	1),
(28,	'2013_10_01_000001_Db_Backend_Users',	2),
(29,	'2013_10_01_000002_Db_Backend_User_Groups',	2),
(30,	'2013_10_01_000003_Db_Backend_Users_Groups',	2),
(31,	'2013_10_01_000004_Db_Backend_User_Throttle',	2),
(32,	'2014_01_04_000005_Db_Backend_User_Preferences',	2),
(33,	'2014_10_01_000006_Db_Backend_Access_Log',	2),
(34,	'2017_10_01_000010_Db_Backend_User_Roles',	2),
(35,	'2018_12_16_000011_Db_Backend_Add_Deleted_At',	2),
(36,	'2022_10_01_000012_Db_Backend_User_Roles_Sortable',	2),
(37,	'2023_10_01_000013_Db_Add_Site_To_Preferences',	2),
(38,	'2023_10_01_000014_Db_Add_User_Expired_Password',	2),
(39,	'2024_10_01_000017_Db_Migrate_v4_0_0',	2),
(40,	'2014_10_01_000001_Db_Cms_Theme_Data',	3),
(41,	'2017_10_01_000003_Db_Cms_Theme_Logs',	3),
(42,	'2018_11_01_000001_Db_Cms_Theme_Templates',	3),
(43,	'2025_10_01_000001_Db_Dashboard_Dashboards',	4),
(44,	'2025_10_01_000002_Db_Dashboard_Report_Data_Cache',	4),
(45,	'2025_10_01_000003_Db_Dashboard_Traffic_Stats_Pageviews',	4),
(46,	'2025_10_01_000004_Db_Add_Dashboard_Overrides',	4),
(47,	'2025_10_01_000005_Db_Dashboard_Traffic_Stats_Add_Site',	4),
(48,	'2026_10_01_000006_Db_Dashboard_Roles',	4),
(49,	'2021_05_01_000001_Db_Tailor_Globals',	5),
(50,	'2021_05_01_000002_Db_Tailor_Content',	5),
(51,	'2021_06_01_000003_Db_Tailor_PreviewToken',	5),
(52,	'2023_10_01_000004_Db_Tailor_Content_Joins',	5),
(53,	'2024_10_01_000005_Db_Add_Parent_To_Repeaters',	5);

DROP TABLE IF EXISTS "rainlab_user_preferences";
DROP SEQUENCE IF EXISTS "public".rainlab_user_preferences_id_seq;
CREATE SEQUENCE "public".rainlab_user_preferences_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."rainlab_user_preferences" (
    "id" bigint DEFAULT nextval('rainlab_user_preferences_id_seq') NOT NULL,
    "user_id" bigint,
    "item" character varying(255),
    "value" text,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "rainlab_user_preferences_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX rainlab_user_preferences_user_id_index ON public.rainlab_user_preferences USING btree (user_id);

CREATE INDEX rainlab_user_preferences_item_index ON public.rainlab_user_preferences USING btree (item);


DROP TABLE IF EXISTS "rainlab_user_user_logs";
DROP SEQUENCE IF EXISTS "public".rainlab_user_user_logs_id_seq;
CREATE SEQUENCE "public".rainlab_user_user_logs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."rainlab_user_user_logs" (
    "id" bigint DEFAULT nextval('rainlab_user_user_logs_id_seq') NOT NULL,
    "user_id" bigint,
    "type" character varying(255),
    "data" text,
    "comment" text,
    "is_comment" boolean DEFAULT false NOT NULL,
    "is_system" boolean DEFAULT false NOT NULL,
    "updated_user_id" bigint,
    "created_user_id" bigint,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "rainlab_user_user_logs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX rainlab_user_user_logs_user_id_index ON public.rainlab_user_user_logs USING btree (user_id);

CREATE INDEX rainlab_user_user_logs_is_comment_index ON public.rainlab_user_user_logs USING btree (is_comment);


DROP TABLE IF EXISTS "sessions";
CREATE TABLE "public"."sessions" (
    "id" character varying(255) NOT NULL,
    "payload" text,
    "last_activity" integer,
    "user_id" integer,
    "ip_address" character varying(45),
    "user_agent" text
)
WITH (oids = false);

CREATE UNIQUE INDEX sessions_id_unique ON public.sessions USING btree (id);


DROP TABLE IF EXISTS "system_event_logs";
DROP SEQUENCE IF EXISTS "public".system_event_logs_id_seq;
CREATE SEQUENCE "public".system_event_logs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_event_logs" (
    "id" integer DEFAULT nextval('system_event_logs_id_seq') NOT NULL,
    "level" character varying(255),
    "message" text,
    "details" text,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_event_logs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_event_logs_level_index ON public.system_event_logs USING btree (level);

INSERT INTO "system_event_logs" ("id", "level", "message", "details", "created_at", "updated_at") VALUES
(1,	'error',	'Base exists',	'{"exception":{"class":"Exception","message":"Base exists","code":0,"file":"~\/plugins\/zen\/chub\/classes\/system\/Sqlite.php","line":34,"trace":[{"file":"~\/plugins\/zen\/chub\/updates\/builder_table_create_zen_chub_logs.php","line":11,"call":"Zen\\Chub\\Classes\\System\\Sqlite::create"},{"file":"~\/vendor\/october\/rain\/src\/Database\/Updater.php","line":121,"call":"Zen\\Chub\\Updates\\BuilderTableCreateZenChubLogs->up"},{"file":"~\/vendor\/october\/rain\/src\/Database\/Updater.php","line":50,"call":"October\\Rain\\Database\\Updater->runMethod"},{"file":"~\/modules\/system\/classes\/VersionManager.php","line":503,"call":"October\\Rain\\Database\\Updater->setUp"},{"file":"~\/modules\/system\/classes\/VersionManager.php","line":161,"call":"System\\Classes\\VersionManager->applyDatabaseScript"},{"file":"~\/modules\/system\/classes\/VersionManager.php","line":93,"call":"System\\Classes\\VersionManager->applyPluginUpdate"},{"file":"~\/modules\/system\/classes\/updatemanager\/ManagesPlugins.php","line":113,"call":"System\\Classes\\VersionManager->updatePlugin"},{"file":"~\/modules\/system\/classes\/updatemanager\/ManagesPlugins.php","line":94,"call":"System\\Classes\\UpdateManager->migratePlugin"},{"file":"~\/modules\/system\/classes\/UpdateManager.php","line":103,"call":"System\\Classes\\UpdateManager->migratePlugins"},{"file":"~\/modules\/system\/console\/OctoberMigrate.php","line":47,"call":"System\\Classes\\UpdateManager->update"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":36,"call":"System\\Console\\OctoberMigrate->handle"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Util.php","line":43,"call":"Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":96,"call":"Illuminate\\Container\\Util::unwrapIfClosure"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":35,"call":"Illuminate\\Container\\BoundMethod::callBoundMethod"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Container.php","line":799,"call":"Illuminate\\Container\\BoundMethod::call"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Command.php","line":211,"call":"Illuminate\\Container\\Container->call"},{"file":"~\/vendor\/symfony\/console\/Command\/Command.php","line":341,"call":"Illuminate\\Console\\Command->execute"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Command.php","line":180,"call":"Symfony\\Component\\Console\\Command\\Command->run"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":1117,"call":"Illuminate\\Console\\Command->run"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":356,"call":"Symfony\\Component\\Console\\Application->doRunCommand"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":195,"call":"Symfony\\Component\\Console\\Application->doRun"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Console\/Kernel.php","line":198,"call":"Symfony\\Component\\Console\\Application->run"},{"file":"~\/artisan","line":33,"call":"Illuminate\\Foundation\\Console\\Kernel->handle"}]}}',	'2026-04-28 18:55:48',	'2026-04-28 18:55:48'),
(2,	'error',	'curl error 28 while downloading https://gateway.octobercms.com/composer/p2/rainlab/builder-plugin.json: Operation timed out after 300018 milliseconds with 15693 bytes received',	'{"exception":{"class":"Composer\\Downloader\\TransportException","message":"curl error 28 while downloading https:\/\/gateway.octobercms.com\/composer\/p2\/rainlab\/builder-plugin.json: Operation timed out after 300018 milliseconds with 15693 bytes received","code":400,"file":"~\/vendor\/composer\/composer\/src\/Composer\/Util\/Http\/CurlDownloader.php","line":401,"trace":[{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Util\/HttpDownloader.php","line":392,"call":"Composer\\Util\\Http\\CurlDownloader->tick"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Util\/Loop.php","line":86,"call":"Composer\\Util\\HttpDownloader->countActiveJobs"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Repository\/ComposerRepository.php","line":1085,"call":"Composer\\Util\\Loop->wait"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Repository\/ComposerRepository.php","line":540,"call":"Composer\\Repository\\ComposerRepository->loadAsyncPackages"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Repository\/FilterRepository.php","line":125,"call":"Composer\\Repository\\ComposerRepository->loadPackages"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/DependencyResolver\/PoolBuilder.php","line":447,"call":"Composer\\Repository\\FilterRepository->loadPackages"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/DependencyResolver\/PoolBuilder.php","line":285,"call":"Composer\\DependencyResolver\\PoolBuilder->loadPackagesMarkedForLoading"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Repository\/RepositorySet.php","line":347,"call":"Composer\\DependencyResolver\\PoolBuilder->buildPool"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Installer.php","line":505,"call":"Composer\\Repository\\RepositorySet->createPool"},{"file":"~\/vendor\/composer\/composer\/src\/Composer\/Installer.php","line":302,"call":"Composer\\Installer->doUpdate"},{"file":"~\/vendor\/october\/rain\/src\/Composer\/ComposerManager.php","line":69,"call":"Composer\\Installer->run"},{"file":"~\/modules\/system\/console\/OctoberUpdate.php","line":50,"call":"October\\Rain\\Composer\\ComposerManager->update"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":36,"call":"System\\Console\\OctoberUpdate->handle"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Util.php","line":43,"call":"Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":96,"call":"Illuminate\\Container\\Util::unwrapIfClosure"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":35,"call":"Illuminate\\Container\\BoundMethod::callBoundMethod"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Container.php","line":799,"call":"Illuminate\\Container\\BoundMethod::call"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Command.php","line":211,"call":"Illuminate\\Container\\Container->call"},{"file":"~\/vendor\/symfony\/console\/Command\/Command.php","line":341,"call":"Illuminate\\Console\\Command->execute"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Command.php","line":180,"call":"Symfony\\Component\\Console\\Command\\Command->run"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":1117,"call":"Illuminate\\Console\\Command->run"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":356,"call":"Symfony\\Component\\Console\\Application->doRunCommand"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":195,"call":"Symfony\\Component\\Console\\Application->doRun"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Console\/Kernel.php","line":198,"call":"Symfony\\Component\\Console\\Application->run"},{"file":"~\/artisan","line":33,"call":"Illuminate\\Foundation\\Console\\Kernel->handle"}]}}',	'2026-04-28 19:16:34',	'2026-04-28 19:16:34'),
(3,	'error',	'Base not exists',	'{"exception":{"class":"Exception","message":"Base not exists","code":0,"file":"~\/plugins\/zen\/chub\/classes\/system\/Sqlite.php","line":46,"trace":[{"file":"~\/plugins\/zen\/chub\/classes\/system\/LogsApp.php","line":43,"call":"Zen\\Chub\\Classes\\System\\Sqlite::connect"},{"file":"~\/plugins\/zen\/chub\/classes\/system\/LogsApp.php","line":30,"call":"Zen\\Chub\\Classes\\System\\LogsApp::getBase"},{"file":"~\/plugins\/zen\/chub\/classes\/system\/LogsApp.php","line":14,"call":"Zen\\Chub\\Classes\\System\\LogsApp::addLog"},{"file":"~\/plugins\/zen\/chub\/classes\/system\/CronApp.php","line":47,"call":"Zen\\Chub\\Classes\\System\\LogsApp::addInfo"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":36,"call":"Zen\\Chub\\Classes\\System\\CronApp->{closure:Zen\\Chub\\Classes\\System\\CronApp::execute():40}"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":36,"call":"Closure->__invoke"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Util.php","line":43,"call":"Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":96,"call":"Illuminate\\Container\\Util::unwrapIfClosure"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":35,"call":"Illuminate\\Container\\BoundMethod::callBoundMethod"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Container.php","line":799,"call":"Illuminate\\Container\\BoundMethod::call"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Scheduling\/CallbackEvent.php","line":117,"call":"Illuminate\\Container\\Container->call"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Scheduling\/Event.php","line":185,"call":"Illuminate\\Console\\Scheduling\\CallbackEvent->execute"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Scheduling\/Event.php","line":134,"call":"Illuminate\\Console\\Scheduling\\Event->start"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Scheduling\/CallbackEvent.php","line":76,"call":"Illuminate\\Console\\Scheduling\\Event->run"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Scheduling\/ScheduleRunCommand.php","line":197,"call":"Illuminate\\Console\\Scheduling\\CallbackEvent->run"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/View\/Components\/Task.php","line":41,"call":"Illuminate\\Console\\Scheduling\\ScheduleRunCommand->{closure:Illuminate\\Console\\Scheduling\\ScheduleRunCommand::runEvent():191}"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/View\/Components\/Factory.php","line":59,"call":"Illuminate\\Console\\View\\Components\\Task->render"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Scheduling\/ScheduleRunCommand.php","line":191,"call":"Illuminate\\Console\\View\\Components\\Factory->__call"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Scheduling\/ScheduleRunCommand.php","line":134,"call":"Illuminate\\Console\\Scheduling\\ScheduleRunCommand->runEvent"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":36,"call":"Illuminate\\Console\\Scheduling\\ScheduleRunCommand->handle"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Util.php","line":43,"call":"Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":96,"call":"Illuminate\\Container\\Util::unwrapIfClosure"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/BoundMethod.php","line":35,"call":"Illuminate\\Container\\BoundMethod::callBoundMethod"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Container\/Container.php","line":799,"call":"Illuminate\\Container\\BoundMethod::call"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Command.php","line":211,"call":"Illuminate\\Container\\Container->call"},{"file":"~\/vendor\/symfony\/console\/Command\/Command.php","line":341,"call":"Illuminate\\Console\\Command->execute"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Console\/Command.php","line":180,"call":"Symfony\\Component\\Console\\Command\\Command->run"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":1117,"call":"Illuminate\\Console\\Command->run"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":356,"call":"Symfony\\Component\\Console\\Application->doRunCommand"},{"file":"~\/vendor\/symfony\/console\/Application.php","line":195,"call":"Symfony\\Component\\Console\\Application->doRun"},{"file":"~\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Console\/Kernel.php","line":198,"call":"Symfony\\Component\\Console\\Application->run"},{"file":"~\/artisan","line":33,"call":"Illuminate\\Foundation\\Console\\Kernel->handle"}]}}',	'2026-04-28 19:24:00',	'2026-04-28 19:24:00');

DROP TABLE IF EXISTS "system_files";
DROP SEQUENCE IF EXISTS "public".system_files_id_seq;
CREATE SEQUENCE "public".system_files_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_files" (
    "id" integer DEFAULT nextval('system_files_id_seq') NOT NULL,
    "disk_name" character varying(255) NOT NULL,
    "file_name" character varying(255) NOT NULL,
    "file_size" integer NOT NULL,
    "content_type" character varying(255) NOT NULL,
    "title" character varying(255),
    "description" text,
    "field" character varying(255),
    "attachment_id" integer,
    "attachment_type" character varying(255),
    "is_public" boolean DEFAULT true NOT NULL,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_files_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_files_master_index ON public.system_files USING btree (attachment_type, attachment_id, field);


DROP TABLE IF EXISTS "system_mail_layouts";
DROP SEQUENCE IF EXISTS "public".system_mail_layouts_id_seq;
CREATE SEQUENCE "public".system_mail_layouts_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_mail_layouts" (
    "id" integer DEFAULT nextval('system_mail_layouts_id_seq') NOT NULL,
    "name" character varying(255),
    "code" character varying(255),
    "content_html" text,
    "content_text" text,
    "content_css" text,
    "is_locked" boolean DEFAULT false NOT NULL,
    "options" text,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_mail_layouts_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "system_mail_partials";
DROP SEQUENCE IF EXISTS "public".system_mail_partials_id_seq;
CREATE SEQUENCE "public".system_mail_partials_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_mail_partials" (
    "id" integer DEFAULT nextval('system_mail_partials_id_seq') NOT NULL,
    "name" character varying(255),
    "code" character varying(255),
    "content_html" text,
    "content_text" text,
    "is_custom" boolean DEFAULT false NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_mail_partials_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "system_mail_templates";
DROP SEQUENCE IF EXISTS "public".system_mail_templates_id_seq;
CREATE SEQUENCE "public".system_mail_templates_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_mail_templates" (
    "id" integer DEFAULT nextval('system_mail_templates_id_seq') NOT NULL,
    "code" character varying(255),
    "subject" character varying(255),
    "description" text,
    "content_html" text,
    "content_text" text,
    "layout_id" integer,
    "is_custom" boolean DEFAULT false NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_mail_templates_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_mail_templates_layout_id_index ON public.system_mail_templates USING btree (layout_id);


DROP TABLE IF EXISTS "system_parameters";
DROP SEQUENCE IF EXISTS "public".system_parameters_id_seq;
CREATE SEQUENCE "public".system_parameters_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_parameters" (
    "id" integer DEFAULT nextval('system_parameters_id_seq') NOT NULL,
    "namespace" character varying(100) NOT NULL,
    "group" character varying(50) NOT NULL,
    "item" character varying(150) NOT NULL,
    "value" text,
    CONSTRAINT "system_parameters_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX item_index ON public.system_parameters USING btree (namespace, "group", item);

INSERT INTO "system_parameters" ("id", "namespace", "group", "item", "value") VALUES
(1,	'system',	'update',	'count',	'0'),
(2,	'system',	'core',	'since',	'"2026-04-28 18:55:47"'),
(3,	'system',	'core',	'bash',	'"cfacf70fb2d4b3b5fe66902ed02d5d1dHQtWXNdJJIVtjg1qGc2YVvg0SHf3bySq1ZpLo7i9"'),
(4,	'system',	'project',	'is_stale',	'0'),
(5,	'system',	'project',	'is_active',	'true');

DROP TABLE IF EXISTS "system_plugin_history";
DROP SEQUENCE IF EXISTS "public".system_plugin_history_id_seq;
CREATE SEQUENCE "public".system_plugin_history_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_plugin_history" (
    "id" integer DEFAULT nextval('system_plugin_history_id_seq') NOT NULL,
    "code" character varying(255) NOT NULL,
    "type" character varying(20) NOT NULL,
    "version" character varying(50) NOT NULL,
    "detail" text,
    "created_at" timestamp(0),
    CONSTRAINT "system_plugin_history_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_plugin_history_code_index ON public.system_plugin_history USING btree (code);

CREATE INDEX system_plugin_history_type_index ON public.system_plugin_history USING btree (type);

INSERT INTO "system_plugin_history" ("id", "code", "type", "version", "detail", "created_at") VALUES
(110,	'October.Demo',	'comment',	'1.0.1',	'First version of Demo',	'2026-04-28 18:55:47'),
(111,	'RainLab.Builder',	'comment',	'1.0.1',	'Initialize plugin.',	'2026-04-28 18:55:47'),
(112,	'RainLab.Builder',	'comment',	'1.0.2',	'Fixes the problem with selecting a plugin. Minor localization corrections. Configuration files in the list and form behaviors are now autocomplete.',	'2026-04-28 18:55:47'),
(113,	'RainLab.Builder',	'comment',	'1.0.3',	'Improved handling of the enum data type.',	'2026-04-28 18:55:47'),
(114,	'RainLab.Builder',	'comment',	'1.0.4',	'Added user permissions to work with the Builder.',	'2026-04-28 18:55:47'),
(115,	'RainLab.Builder',	'comment',	'1.0.5',	'Fixed permissions registration.',	'2026-04-28 18:55:47'),
(116,	'RainLab.Builder',	'comment',	'1.0.6',	'Fixed front-end record ordering in the Record List component.',	'2026-04-28 18:55:47'),
(117,	'RainLab.Builder',	'comment',	'1.0.7',	'Builder settings are now protected with user permissions. The database table column list is scrollable now. Minor code cleanup.',	'2026-04-28 18:55:47'),
(118,	'RainLab.Builder',	'comment',	'1.0.8',	'Added the Reorder Controller behavior.',	'2026-04-28 18:55:47'),
(119,	'RainLab.Builder',	'comment',	'1.0.9',	'Minor API and UI updates.',	'2026-04-28 18:55:47'),
(120,	'RainLab.Builder',	'comment',	'1.0.10',	'Minor styling update.',	'2026-04-28 18:55:47'),
(121,	'RainLab.Builder',	'comment',	'1.0.11',	'Fixed a bug where clicking placeholder in a repeater would open Inspector. Fixed a problem with saving forms with repeaters in tabs. Minor style fix.',	'2026-04-28 18:55:47'),
(122,	'RainLab.Builder',	'comment',	'1.0.12',	'Added support for the Trigger property to the Media Finder widget configuration. Names of form fields and list columns definition files can now contain underscores.',	'2026-04-28 18:55:47'),
(123,	'RainLab.Builder',	'comment',	'1.0.13',	'Minor styling fix on the database editor.',	'2026-04-28 18:55:47'),
(124,	'RainLab.Builder',	'comment',	'1.0.14',	'Added support for published_at timestamp field',	'2026-04-28 18:55:47'),
(125,	'RainLab.Builder',	'comment',	'1.0.15',	'Fixed a bug where saving a localization string in Inspector could cause a JavaScript error. Added support for Timestamps and Soft Deleting for new models.',	'2026-04-28 18:55:47'),
(126,	'RainLab.Builder',	'comment',	'1.0.16',	'Fixed a bug when saving a form with the Repeater widget in a tab could create invalid fields in the form''s outside area. Added a check that prevents creating localization strings inside other existing strings.',	'2026-04-28 18:55:47'),
(127,	'RainLab.Builder',	'comment',	'1.0.17',	'Added support Trigger attribute support for RecordFinder and Repeater form widgets.',	'2026-04-28 18:55:47'),
(128,	'RainLab.Builder',	'comment',	'1.0.18',	'Fixes a bug where ''::class'' notations in a model class definition could prevent the model from appearing in the Builder model list. Added emptyOption property support to the dropdown form control.',	'2026-04-28 18:55:47'),
(129,	'RainLab.Builder',	'comment',	'1.0.19',	'Added a feature allowing to add all database columns to a list definition. Added max length validation for database table and column names.',	'2026-04-28 18:55:47'),
(197,	'RainLab.User',	'comment',	'3.3.1',	'Bump the JWT library version',	'2026-04-28 18:55:48'),
(130,	'RainLab.Builder',	'comment',	'1.0.20',	'Fixes a bug where form the builder could trigger the "current.hasAttribute is not a function" error.',	'2026-04-28 18:55:47'),
(131,	'RainLab.Builder',	'comment',	'1.0.21',	'Back-end navigation sort order updated.',	'2026-04-28 18:55:47'),
(132,	'RainLab.Builder',	'comment',	'1.0.22',	'Added scopeValue property to the RecordList component.',	'2026-04-28 18:55:47'),
(133,	'RainLab.Builder',	'comment',	'1.0.23',	'Added support for balloon-selector field type, added Brazilian Portuguese translation, fixed some bugs',	'2026-04-28 18:55:47'),
(134,	'RainLab.Builder',	'comment',	'1.0.24',	'Added support for tag list field type, added read only toggle for fields. Prevent plugins from using reserved PHP keywords for class names and namespaces',	'2026-04-28 18:55:47'),
(135,	'RainLab.Builder',	'comment',	'1.0.25',	'Allow editing of migration code in the "Migration" popup when saving changes in the database editor.',	'2026-04-28 18:55:47'),
(136,	'RainLab.Builder',	'comment',	'1.0.26',	'Allow special default values for columns and added new "Add ID column" button to database editor.',	'2026-04-28 18:55:47'),
(137,	'RainLab.Builder',	'comment',	'1.0.27',	'Added ability to use ''scope'' in a form relation field, added ability to change the sort order of versions and added additional properties for repeater widget in form builder. Added Polish translation.',	'2026-04-28 18:55:47'),
(138,	'RainLab.Builder',	'comment',	'1.0.28',	'Fixes support for PHP 8',	'2026-04-28 18:55:47'),
(139,	'RainLab.Builder',	'comment',	'1.0.29',	'Disable touch device detection',	'2026-04-28 18:55:47'),
(140,	'RainLab.Builder',	'comment',	'1.0.30',	'Minor styling improvements',	'2026-04-28 18:55:47'),
(141,	'RainLab.Builder',	'comment',	'1.0.31',	'Added support for more rich editor and file upload properties',	'2026-04-28 18:55:47'),
(142,	'RainLab.Builder',	'comment',	'1.0.32',	'Minor styling improvements',	'2026-04-28 18:55:47'),
(143,	'RainLab.Builder',	'comment',	'1.1.0',	'Adds feature for adding database fields to a form definition.',	'2026-04-28 18:55:47'),
(144,	'RainLab.Builder',	'comment',	'1.1.1',	'Adds DBAL timestamp column type. Adds database prefix support. Fixes various bugs.',	'2026-04-28 18:55:47'),
(145,	'RainLab.Builder',	'comment',	'1.1.2',	'Compatibility with October CMS v2.2',	'2026-04-28 18:55:47'),
(146,	'RainLab.Builder',	'comment',	'1.1.3',	'Adds comment support to database tables.',	'2026-04-28 18:55:47'),
(147,	'RainLab.Builder',	'comment',	'1.1.4',	'Fixes duplication bug saving backend menu permissions.',	'2026-04-28 18:55:47'),
(148,	'RainLab.Builder',	'comment',	'1.2.0',	'Improve support with October v3.0',	'2026-04-28 18:55:47'),
(149,	'RainLab.Builder',	'comment',	'1.2.2',	'Compatibility updates.',	'2026-04-28 18:55:47'),
(150,	'RainLab.Builder',	'comment',	'1.2.3',	'Fixes issue when removing items from permissions and menus.',	'2026-04-28 18:55:47'),
(151,	'RainLab.Builder',	'comment',	'1.2.5',	'Fixes validator conflict with other plugins.',	'2026-04-28 18:55:47'),
(152,	'RainLab.Builder',	'comment',	'1.2.6',	'Compatibility with October v3.1',	'2026-04-28 18:55:47'),
(153,	'RainLab.Builder',	'comment',	'2.0.1',	'Adds Tailor blueprint importer and code editor.',	'2026-04-28 18:55:47'),
(154,	'RainLab.Builder',	'comment',	'2.0.2',	'Fixes visual bug when tab fields overflow.',	'2026-04-28 18:55:47'),
(155,	'RainLab.Builder',	'comment',	'2.0.3',	'Fixes missing import in CMS components.',	'2026-04-28 18:55:47'),
(156,	'RainLab.Builder',	'comment',	'2.0.4',	'Fixes bad method name in controller model.',	'2026-04-28 18:55:47'),
(157,	'RainLab.Builder',	'comment',	'2.0.5',	'Fixes bug adding data table controls.',	'2026-04-28 18:55:47'),
(158,	'RainLab.Builder',	'comment',	'2.0.6',	'Fixes importing Tailor multisite globals.',	'2026-04-28 18:55:47'),
(159,	'RainLab.Builder',	'comment',	'2.0.7',	'Compatibility fixes for October v3.6',	'2026-04-28 18:55:47'),
(160,	'RainLab.Builder',	'comment',	'3.0.0',	'Latest version for October v4.0',	'2026-04-28 18:55:47'),
(161,	'RainLab.Builder',	'comment',	'3.0.1',	'Fixes SQL authentication error for some instances',	'2026-04-28 18:55:47'),
(162,	'RainLab.Builder',	'comment',	'3.0.2',	'Block access to this plugin when safe mode is enabled',	'2026-04-28 18:55:47'),
(163,	'RainLab.Builder',	'comment',	'3.0.3',	'Compatibility fixes for October v4.2',	'2026-04-28 18:55:47'),
(164,	'RainLab.User',	'comment',	'1.0.1',	'First version of User',	'2026-04-28 18:55:47'),
(165,	'RainLab.User',	'script',	'1.0.2',	'000001_create_users.php',	'2026-04-28 18:55:47'),
(166,	'RainLab.User',	'script',	'1.0.2',	'000002_create_password_resets.php',	'2026-04-28 18:55:47'),
(167,	'RainLab.User',	'script',	'1.0.2',	'000003_create_user_groups.php',	'2026-04-28 18:55:48'),
(168,	'RainLab.User',	'script',	'1.0.2',	'000004_create_user_preferences.php',	'2026-04-28 18:55:48'),
(169,	'RainLab.User',	'script',	'1.0.2',	'000005_create_user_logs.php',	'2026-04-28 18:55:48'),
(170,	'RainLab.User',	'comment',	'1.0.2',	'Set up database tables',	'2026-04-28 18:55:48'),
(171,	'RainLab.User',	'script',	'1.0.3',	'seed_tables.php',	'2026-04-28 18:55:48'),
(172,	'RainLab.User',	'comment',	'1.0.3',	'Seed all database tables',	'2026-04-28 18:55:48'),
(173,	'RainLab.User',	'comment',	'1.1.0',	'Profile fields and Locations have been removed.',	'2026-04-28 18:55:48'),
(174,	'RainLab.User',	'comment',	'1.2.0',	'Users can now deactivate their own accounts.',	'2026-04-28 18:55:48'),
(175,	'RainLab.User',	'comment',	'1.3.0',	'Introduced guest user accounts.',	'2026-04-28 18:55:48'),
(176,	'RainLab.User',	'comment',	'1.4.0',	'The Notifications tab in User Settings has been removed.',	'2026-04-28 18:55:48'),
(177,	'RainLab.User',	'comment',	'1.5.0',	'Required password length is now a minimum of 8 characters. Previous passwords will not be affected until the next password change.',	'2026-04-28 18:55:48'),
(178,	'RainLab.User',	'comment',	'1.6.0',	'Apply persistence settings on activation and registration. Fixes last seen touched when impersonating. Fixes user suspension not clearing.',	'2026-04-28 18:55:48'),
(179,	'RainLab.User',	'comment',	'1.7.0',	'Add password policy',	'2026-04-28 18:55:48'),
(180,	'RainLab.User',	'comment',	'1.7.1',	'Fixes compatibility with legacy sites',	'2026-04-28 18:55:48'),
(181,	'RainLab.User',	'comment',	'2.0.0',	'Compatibility with October v3 only',	'2026-04-28 18:55:48'),
(182,	'RainLab.User',	'comment',	'2.1.0',	'Adds bearer token (JWT) support to session component',	'2026-04-28 18:55:48'),
(183,	'RainLab.User',	'script',	'3.0.0',	'migrate_v3_0_0.php',	'2026-04-28 18:55:48'),
(184,	'RainLab.User',	'comment',	'3.0.0',	'Major Upgrade to User Plugin',	'2026-04-28 18:55:48'),
(185,	'RainLab.User',	'comment',	'3.0.4',	'Fixes bug in JWT authentication check',	'2026-04-28 18:55:48'),
(186,	'RainLab.User',	'comment',	'3.0.5',	'Adds permission for viewing user activity log',	'2026-04-28 18:55:48'),
(187,	'RainLab.User',	'comment',	'3.0.7',	'Fixes missing notification variables in mail templates',	'2026-04-28 18:55:48'),
(188,	'RainLab.User',	'script',	'3.1.0',	'migrate_v3_1_0.php',	'2026-04-28 18:55:48'),
(189,	'RainLab.User',	'comment',	'3.1.0',	'New email verification logic',	'2026-04-28 18:55:48'),
(190,	'RainLab.User',	'comment',	'3.1.1',	'Fixes compatibility with Mall plugin',	'2026-04-28 18:55:48'),
(191,	'RainLab.User',	'comment',	'3.1.3',	'Translation updates',	'2026-04-28 18:55:48'),
(192,	'RainLab.User',	'comment',	'3.2.0',	'Fixes events with 2FA, requires October v3.7 or above',	'2026-04-28 18:55:48'),
(193,	'RainLab.User',	'comment',	'3.2.1',	'Fixes support with Tailor integration',	'2026-04-28 18:55:48'),
(194,	'RainLab.User',	'comment',	'3.2.2',	'Fixes compatibility with October v4',	'2026-04-28 18:55:48'),
(195,	'RainLab.User',	'comment',	'3.2.3',	'Fixes column definition in user tailor field',	'2026-04-28 18:55:48'),
(196,	'RainLab.User',	'comment',	'3.3.0',	'Adjusts the group navigation',	'2026-04-28 18:55:48'),
(198,	'RainLab.User',	'comment',	'3.3.2',	'Switch JWT algorithm to match Laravel key length',	'2026-04-28 18:55:48'),
(199,	'RainLab.User',	'comment',	'3.3.3',	'Adds Soft Delete Users to the settings page',	'2026-04-28 18:55:48'),
(200,	'RainLab.User',	'comment',	'3.4.0',	'Improves the activity timeline',	'2026-04-28 18:55:48'),
(201,	'RainLab.User',	'comment',	'3.5.0',	'Adds feature to Merge Users, including Guest accounts',	'2026-04-28 18:55:48'),
(325,	'Zen.Robots',	'comment',	'1.0.1',	'First version of robots.txt',	'2026-04-28 18:56:07'),
(326,	'Zen.Robots',	'script',	'1.0.2',	'robots_init.php',	'2026-04-28 18:56:07'),
(327,	'Zen.Robots',	'comment',	'1.0.2',	'Set default settings after install',	'2026-04-28 18:56:07'),
(328,	'Zen.Robots',	'comment',	'1.0.3',	'Added translations and permission control',	'2026-04-28 18:56:07'),
(329,	'Zen.Robots',	'comment',	'1.0.4',	'Added Hungarian translate (thanks to Szabó Gergő)',	'2026-04-28 18:56:07'),
(330,	'Zen.Robots',	'comment',	'1.0.5',	'Small fixes',	'2026-04-28 18:56:07'),
(331,	'Zen.Robots',	'comment',	'1.0.6',	'Security fixes, replacing the super global variable $_SERVER',	'2026-04-28 18:56:07'),
(332,	'Zen.Robots',	'comment',	'1.0.7',	'Fix version in composer.json',	'2026-04-28 18:56:07'),
(333,	'Zen.Robots',	'comment',	'1.0.8',	'Fix version in composer.json',	'2026-04-28 18:56:07'),
(334,	'Zen.Robots',	'comment',	'1.0.9',	'Fix release version tag',	'2026-04-28 18:56:07'),
(335,	'Zen.Tester',	'comment',	'1.0.1',	'Initialize plugin',	'2026-04-28 18:56:07');

DROP TABLE IF EXISTS "system_plugin_site_groups";
DROP SEQUENCE IF EXISTS "public".system_plugin_site_groups_id_seq;
CREATE SEQUENCE "public".system_plugin_site_groups_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_plugin_site_groups" (
    "id" integer DEFAULT nextval('system_plugin_site_groups_id_seq') NOT NULL,
    "plugin_code" character varying(255) NOT NULL,
    "site_id" integer,
    "site_group_id" integer,
    "is_enabled" boolean DEFAULT true NOT NULL,
    CONSTRAINT "system_plugin_site_groups_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX plugin_site_group_unique ON public.system_plugin_site_groups USING btree (plugin_code, site_id, site_group_id);

CREATE INDEX system_plugin_site_groups_plugin_code_index ON public.system_plugin_site_groups USING btree (plugin_code);

CREATE INDEX system_plugin_site_groups_site_id_index ON public.system_plugin_site_groups USING btree (site_id);

CREATE INDEX system_plugin_site_groups_site_group_id_index ON public.system_plugin_site_groups USING btree (site_group_id);


DROP TABLE IF EXISTS "system_plugin_versions";
DROP SEQUENCE IF EXISTS "public".system_plugin_versions_id_seq;
CREATE SEQUENCE "public".system_plugin_versions_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_plugin_versions" (
    "id" integer DEFAULT nextval('system_plugin_versions_id_seq') NOT NULL,
    "code" character varying(255) NOT NULL,
    "version" character varying(50) NOT NULL,
    "is_frozen" boolean DEFAULT false NOT NULL,
    "is_disabled" boolean DEFAULT false NOT NULL,
    "created_at" timestamp(0),
    CONSTRAINT "system_plugin_versions_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_plugin_versions_code_index ON public.system_plugin_versions USING btree (code);

INSERT INTO "system_plugin_versions" ("id", "code", "version", "is_frozen", "is_disabled", "created_at") VALUES
(4,	'RainLab.User',	'3.5.0',	'0',	'0',	'2026-04-28 18:55:48'),
(2,	'October.Demo',	'1.0.1',	'0',	'0',	'2026-04-28 18:55:47'),
(7,	'Zen.Robots',	'1.0.9',	'0',	'0',	'2026-04-28 18:56:07'),
(8,	'Zen.Tester',	'1.0.1',	'0',	'0',	'2026-04-28 18:56:07'),
(3,	'RainLab.Builder',	'3.0.3',	'0',	'0',	'2026-04-28 18:55:47');

DROP TABLE IF EXISTS "system_request_logs";
DROP SEQUENCE IF EXISTS "public".system_request_logs_id_seq;
CREATE SEQUENCE "public".system_request_logs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_request_logs" (
    "id" integer DEFAULT nextval('system_request_logs_id_seq') NOT NULL,
    "status_code" integer,
    "url" text,
    "referer" text,
    "count" integer DEFAULT '0' NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_request_logs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "system_revisions";
DROP SEQUENCE IF EXISTS "public".system_revisions_id_seq;
CREATE SEQUENCE "public".system_revisions_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_revisions" (
    "id" integer DEFAULT nextval('system_revisions_id_seq') NOT NULL,
    "revisionable_type" character varying(255) NOT NULL,
    "revisionable_id" integer NOT NULL,
    "user_id" integer,
    "field" character varying(255),
    "cast" character varying(255),
    "old_value" text,
    "new_value" text,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_revisions_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_revisions_revisionable_id_revisionable_type_index ON public.system_revisions USING btree (revisionable_id, revisionable_type);

CREATE INDEX system_revisions_user_id_index ON public.system_revisions USING btree (user_id);

CREATE INDEX system_revisions_field_index ON public.system_revisions USING btree (field);


DROP TABLE IF EXISTS "system_settings";
DROP SEQUENCE IF EXISTS "public".system_settings_id_seq;
CREATE SEQUENCE "public".system_settings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_settings" (
    "id" integer DEFAULT nextval('system_settings_id_seq') NOT NULL,
    "item" character varying(255),
    "value" text,
    "site_id" integer,
    "site_root_id" integer,
    "site_group_id" integer,
    CONSTRAINT "system_settings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_settings_item_index ON public.system_settings USING btree (item);

INSERT INTO "system_settings" ("id", "item", "value", "site_id", "site_root_id", "site_group_id") VALUES
(1,	'zen_crs_settings',	'{
    "sources": [
        {
            "source_code": "waterway",
            "source_name": "Водоход"
        },
        {
            "source_code": "volga",
            "source_name": "Волга Volga"
        },
        {
            "source_code": "gama",
            "source_name": "Гама"
        },
        {
            "source_code": "germes",
            "source_name": "Гермес"
        },
        {
            "source_code": "infoflot",
            "source_name": "Инфофлот"
        },
        {
            "source_code": "volgaline",
            "source_name": "Волга Лайн"
        }
    ]
}
',	NULL,	NULL,	NULL),
(2,	'zen_robots_settings',	'{"content":"User-agent: *\r\nAllow: \/\r\nHost: $domain\r\nSitemap: $domain\/sitemap.xml"}',	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS "system_site_definitions";
DROP SEQUENCE IF EXISTS "public".system_site_definitions_id_seq;
CREATE SEQUENCE "public".system_site_definitions_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_site_definitions" (
    "id" integer DEFAULT nextval('system_site_definitions_id_seq') NOT NULL,
    "name" character varying(255),
    "code" character varying(255),
    "sort_order" integer,
    "is_custom_url" boolean DEFAULT false NOT NULL,
    "app_url" character varying(255),
    "theme" character varying(255),
    "locale" character varying(255),
    "fallback_locale" character varying(255),
    "timezone" character varying(255),
    "is_host_restricted" boolean DEFAULT false NOT NULL,
    "allow_hosts" text,
    "is_prefixed" boolean DEFAULT false NOT NULL,
    "route_prefix" character varying(255),
    "is_styled" boolean DEFAULT false NOT NULL,
    "color_foreground" character varying(255),
    "color_background" character varying(255),
    "is_role_restricted" boolean DEFAULT false NOT NULL,
    "allow_roles" text,
    "is_primary" boolean DEFAULT false NOT NULL,
    "is_enabled" boolean DEFAULT false NOT NULL,
    "is_enabled_edit" boolean DEFAULT false NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "group_id" integer,
    CONSTRAINT "system_site_definitions_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_site_definitions_code_index ON public.system_site_definitions USING btree (code);

CREATE INDEX system_site_definitions_group_id_index ON public.system_site_definitions USING btree (group_id);


DROP TABLE IF EXISTS "system_site_groups";
DROP SEQUENCE IF EXISTS "public".system_site_groups_id_seq;
CREATE SEQUENCE "public".system_site_groups_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_site_groups" (
    "id" integer DEFAULT nextval('system_site_groups_id_seq') NOT NULL,
    "name" character varying(255),
    "code" character varying(255),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "system_site_groups_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX system_site_groups_code_index ON public.system_site_groups USING btree (code);


DROP TABLE IF EXISTS "system_translate_attributes";
DROP SEQUENCE IF EXISTS "public".system_translate_attributes_id_seq;
CREATE SEQUENCE "public".system_translate_attributes_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."system_translate_attributes" (
    "id" integer DEFAULT nextval('system_translate_attributes_id_seq') NOT NULL,
    "model_type" character varying(512) NOT NULL,
    "model_id" integer NOT NULL,
    "locale" character varying(16) NOT NULL,
    "attribute" character varying(128) NOT NULL,
    "value" text,
    CONSTRAINT "system_translate_attributes_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX sys_translate_type_id_locale_index ON public.system_translate_attributes USING btree (model_type, model_id, locale);

CREATE UNIQUE INDEX sys_translate_unique_index ON public.system_translate_attributes USING btree (model_type, model_id, locale, attribute);


DROP TABLE IF EXISTS "tailor_content_joins";
CREATE TABLE "public"."tailor_content_joins" (
    "parent_id" integer,
    "parent_type" character varying(255),
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

CREATE INDEX tailor_content_joins_pidx ON public.tailor_content_joins USING btree (parent_id, parent_type, field_name);

CREATE INDEX tailor_content_joins_ridx ON public.tailor_content_joins USING btree (relation_id, relation_type, field_name);

CREATE INDEX tailor_content_joins_field_name_index ON public.tailor_content_joins USING btree (field_name);

CREATE INDEX tailor_content_joins_site_id_index ON public.tailor_content_joins USING btree (site_id);


DROP TABLE IF EXISTS "tailor_content_schema";
DROP SEQUENCE IF EXISTS "public".tailor_content_schema_id_seq;
CREATE SEQUENCE "public".tailor_content_schema_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."tailor_content_schema" (
    "id" integer DEFAULT nextval('tailor_content_schema_id_seq') NOT NULL,
    "table_name" character varying(255),
    "meta" text,
    "fields" text,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "tailor_content_schema_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX tailor_content_schema_table_name_index ON public.tailor_content_schema USING btree (table_name);

INSERT INTO "tailor_content_schema" ("id", "table_name", "meta", "fields", "deleted_at", "created_at", "updated_at") VALUES
(1,	'xc_edcd102e05254e4db07e633ae6c18db6c',	'{"blueprint_uuid":"edcd102e-0525-4e4d-b07e-633ae6c18db6","blueprint_type":"stream","multisite_sync":false}',	'{"active":{"content":{"type":"mediumText","name":"content","nullable":true},"author_id":{"type":"integer","name":"author_id","autoIncrement":false,"unsigned":true,"nullable":true},"featured_text":{"type":"mediumText","name":"featured_text","nullable":true},"gallery_media":{"type":"mediumText","name":"gallery_media","nullable":true}},"dropped":[]}',	NULL,	'2026-04-28 18:56:10',	'2026-04-28 18:56:10'),
(2,	'xc_b022a74b15e64c6b9eb917efc5103543c',	'{"blueprint_uuid":"b022a74b-15e6-4c6b-9eb9-17efc5103543","blueprint_type":"structure","multisite_sync":false}',	'{"active":{"description":{"type":"text","name":"description","nullable":true}},"dropped":[]}',	NULL,	'2026-04-28 18:56:10',	'2026-04-28 18:56:10'),
(3,	'xc_6947ff28b66047d7924024ca6d58aeaec',	'{"blueprint_uuid":"6947ff28-b660-47d7-9240-24ca6d58aeae","blueprint_type":"entry","multisite_sync":false}',	'{"active":{"avatar":{"type":"mediumText","name":"avatar","nullable":true},"email":{"type":"text","name":"email","nullable":true},"role":{"type":"text","name":"role","nullable":true},"about":{"type":"mediumText","name":"about","nullable":true}},"dropped":[]}',	NULL,	'2026-04-28 18:56:10',	'2026-04-28 18:56:10'),
(4,	'xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c',	'{"blueprint_uuid":"a63fabaf-7c0b-4c74-b36f-7abf1a3ad1c1","blueprint_type":"single","multisite_sync":false}',	'{"active":[],"dropped":[]}',	NULL,	'2026-04-28 18:56:10',	'2026-04-28 18:56:10'),
(5,	'xc_339b11b769ad43c49be16953e7738827c',	'{"blueprint_uuid":"339b11b7-69ad-43c4-9be1-6953e7738827","blueprint_type":"structure","multisite_sync":false}',	'{"active":{"content":{"type":"mediumText","name":"content","nullable":true},"show_in_toc":{"type":"boolean","name":"show_in_toc","nullable":true},"summary_text":{"type":"mediumText","name":"summary_text","nullable":true}},"dropped":[]}',	NULL,	'2026-04-28 18:56:10',	'2026-04-28 18:56:10'),
(6,	'xc_85e471d209b94f3da63b1ae9d92d2879c',	'{"blueprint_uuid":"85e471d2-09b9-4f3d-a63b-1ae9d92d2879","blueprint_type":"entry","multisite_sync":false}',	'{"active":{"slug":{"type":"text","name":"slug","nullable":true}},"dropped":[]}',	NULL,	'2026-04-28 18:56:10',	'2026-04-28 18:56:10');

DROP TABLE IF EXISTS "tailor_global_joins";
CREATE TABLE "public"."tailor_global_joins" (
    "parent_id" integer,
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

CREATE INDEX tailor_global_joins_idx ON public.tailor_global_joins USING btree (relation_id, relation_type);

CREATE INDEX tailor_global_joins_field_name_index ON public.tailor_global_joins USING btree (field_name);

CREATE INDEX tailor_global_joins_site_id_index ON public.tailor_global_joins USING btree (site_id);


DROP TABLE IF EXISTS "tailor_global_repeaters";
DROP SEQUENCE IF EXISTS "public".tailor_global_repeaters_id_seq;
CREATE SEQUENCE "public".tailor_global_repeaters_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."tailor_global_repeaters" (
    "id" integer DEFAULT nextval('tailor_global_repeaters_id_seq') NOT NULL,
    "host_id" integer,
    "host_field" character varying(255),
    "site_id" integer,
    "content_group" character varying(255),
    "content_value" text,
    "content_spawn_path" text,
    "parent_id" integer,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "tailor_global_repeaters_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX tailor_global_repeaters_idx ON public.tailor_global_repeaters USING btree (host_id, host_field);

CREATE INDEX tailor_global_repeaters_site_id_index ON public.tailor_global_repeaters USING btree (site_id);


DROP TABLE IF EXISTS "tailor_globals";
DROP SEQUENCE IF EXISTS "public".tailor_globals_id_seq;
CREATE SEQUENCE "public".tailor_globals_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."tailor_globals" (
    "id" integer DEFAULT nextval('tailor_globals_id_seq') NOT NULL,
    "site_id" integer,
    "site_root_id" integer,
    "blueprint_uuid" character varying(255),
    "content" text,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "tailor_globals_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX tailor_globals_site_id_index ON public.tailor_globals USING btree (site_id);

CREATE INDEX tailor_globals_site_root_id_index ON public.tailor_globals USING btree (site_root_id);

CREATE INDEX tailor_globals_blueprint_uuid_index ON public.tailor_globals USING btree (blueprint_uuid);


DROP TABLE IF EXISTS "tailor_preview_tokens";
DROP SEQUENCE IF EXISTS "public".tailor_preview_tokens_id_seq;
CREATE SEQUENCE "public".tailor_preview_tokens_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."tailor_preview_tokens" (
    "id" integer DEFAULT nextval('tailor_preview_tokens_id_seq') NOT NULL,
    "site_id" integer,
    "route" text,
    "token" character varying(255),
    "count_use" integer DEFAULT '0' NOT NULL,
    "count_limit" integer DEFAULT '0' NOT NULL,
    "created_user_id" integer,
    "expired_at" timestamp(0),
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "tailor_preview_tokens_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX tailor_preview_tokens_site_id_index ON public.tailor_preview_tokens USING btree (site_id);

CREATE INDEX tailor_preview_tokens_token_index ON public.tailor_preview_tokens USING btree (token);


DROP TABLE IF EXISTS "user_groups";
DROP SEQUENCE IF EXISTS "public".user_groups_id_seq;
CREATE SEQUENCE "public".user_groups_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."user_groups" (
    "id" bigint DEFAULT nextval('user_groups_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "code" character varying(255),
    "description" text,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "user_groups_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX user_groups_code_index ON public.user_groups USING btree (code);

INSERT INTO "user_groups" ("id", "name", "code", "description", "created_at", "updated_at") VALUES
(1,	'Guest',	'guest',	'Default group for guest users.',	'2026-04-28 18:55:48',	'2026-04-28 18:55:48'),
(2,	'Registered',	'registered',	'Default group for registered users.',	'2026-04-28 18:55:48',	'2026-04-28 18:55:48');

DROP TABLE IF EXISTS "user_password_resets";
CREATE TABLE "public"."user_password_resets" (
    "email" character varying(255) NOT NULL,
    "token" character varying(255) NOT NULL,
    "created_at" timestamp(0),
    CONSTRAINT "user_password_resets_pkey" PRIMARY KEY ("email")
)
WITH (oids = false);


DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS "public".users_id_seq;
CREATE SEQUENCE "public".users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."users" (
    "id" bigint DEFAULT nextval('users_id_seq') NOT NULL,
    "is_guest" boolean DEFAULT false NOT NULL,
    "is_mail_blocked" boolean DEFAULT false NOT NULL,
    "first_name" character varying(255),
    "last_name" character varying(255),
    "username" character varying(255),
    "email" character varying(255) NOT NULL,
    "notes" text,
    "password" character varying(255) NOT NULL,
    "activation_code" character varying(255),
    "persist_code" character varying(255),
    "remember_token" character varying(255),
    "two_factor_secret" text,
    "two_factor_recovery_codes" text,
    "primary_group_id" bigint,
    "created_ip_address" character varying(255),
    "last_ip_address" character varying(255),
    "banned_reason" text,
    "banned_at" timestamp(0),
    "activated_at" timestamp(0),
    "two_factor_confirmed_at" timestamp(0),
    "last_seen" timestamp(0),
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX users_username_index ON public.users USING btree (username);

CREATE INDEX users_activation_code_index ON public.users USING btree (activation_code);


DROP TABLE IF EXISTS "users_groups";
CREATE TABLE "public"."users_groups" (
    "user_id" bigint NOT NULL,
    "user_group_id" bigint NOT NULL,
    CONSTRAINT "users_groups_pkey" PRIMARY KEY ("user_id", "user_group_id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "xc_339b11b769ad43c49be16953e7738827c";
DROP SEQUENCE IF EXISTS "public".xc_339b11b769ad43c49be16953e7738827c_id_seq;
CREATE SEQUENCE "public".xc_339b11b769ad43c49be16953e7738827c_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_339b11b769ad43c49be16953e7738827c" (
    "id" integer DEFAULT nextval('xc_339b11b769ad43c49be16953e7738827c_id_seq') NOT NULL,
    "site_id" integer,
    "site_root_id" integer,
    "blueprint_uuid" character varying(255),
    "content_group" character varying(255),
    "title" character varying(255),
    "slug" character varying(255),
    "is_enabled" boolean,
    "published_at" timestamp(0),
    "published_at_date" timestamp(0),
    "expired_at" timestamp(0),
    "draft_mode" integer DEFAULT '1' NOT NULL,
    "primary_id" integer,
    "primary_attrs" text,
    "is_version" boolean DEFAULT false NOT NULL,
    "fullslug" character varying(255),
    "parent_id" integer,
    "nest_left" integer,
    "nest_right" integer,
    "nest_depth" integer,
    "content" text,
    "show_in_toc" boolean,
    "summary_text" text,
    "created_user_id" integer,
    "updated_user_id" integer,
    "deleted_user_id" integer,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_339b11b769ad43c49be16953e7738827c_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_339b11b769ad43c49be16953e7738827c" IS 'Content for Article [Page\\Article].';

CREATE INDEX xc_339b11b769ad43c49be16953e7738827c_site_id_index ON public.xc_339b11b769ad43c49be16953e7738827c USING btree (site_id);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827c_site_root_id_index ON public.xc_339b11b769ad43c49be16953e7738827c USING btree (site_root_id);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827c_blueprint_uuid_index ON public.xc_339b11b769ad43c49be16953e7738827c USING btree (blueprint_uuid);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827c_content_group_index ON public.xc_339b11b769ad43c49be16953e7738827c USING btree (content_group);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827c_slug_index ON public.xc_339b11b769ad43c49be16953e7738827c USING btree (slug);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827c_primary_id_index ON public.xc_339b11b769ad43c49be16953e7738827c USING btree (primary_id);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827c_fullslug_index ON public.xc_339b11b769ad43c49be16953e7738827c USING btree (fullslug);


DROP TABLE IF EXISTS "xc_339b11b769ad43c49be16953e7738827j";
CREATE TABLE "public"."xc_339b11b769ad43c49be16953e7738827j" (
    "parent_id" integer,
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_339b11b769ad43c49be16953e7738827j" IS 'Joins for Article [Page\\Article].';

CREATE INDEX xc_339b11b769ad43c49be16953e7738827j_idx ON public.xc_339b11b769ad43c49be16953e7738827j USING btree (parent_id, relation_type, field_name);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827j_field_name_index ON public.xc_339b11b769ad43c49be16953e7738827j USING btree (field_name);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827j_site_id_index ON public.xc_339b11b769ad43c49be16953e7738827j USING btree (site_id);


DROP TABLE IF EXISTS "xc_339b11b769ad43c49be16953e7738827r";
DROP SEQUENCE IF EXISTS "public".xc_339b11b769ad43c49be16953e7738827r_id_seq;
CREATE SEQUENCE "public".xc_339b11b769ad43c49be16953e7738827r_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_339b11b769ad43c49be16953e7738827r" (
    "id" integer DEFAULT nextval('xc_339b11b769ad43c49be16953e7738827r_id_seq') NOT NULL,
    "host_id" integer,
    "host_field" character varying(255),
    "site_id" integer,
    "content_group" character varying(255),
    "content_value" text,
    "content_spawn_path" text,
    "parent_id" integer,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_339b11b769ad43c49be16953e7738827r_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_339b11b769ad43c49be16953e7738827r" IS 'Repeaters for Article [Page\\Article].';

CREATE INDEX xc_339b11b769ad43c49be16953e7738827r_idx ON public.xc_339b11b769ad43c49be16953e7738827r USING btree (host_id, host_field);

CREATE INDEX xc_339b11b769ad43c49be16953e7738827r_site_id_index ON public.xc_339b11b769ad43c49be16953e7738827r USING btree (site_id);


DROP TABLE IF EXISTS "xc_6947ff28b66047d7924024ca6d58aeaec";
DROP SEQUENCE IF EXISTS "public".xc_6947ff28b66047d7924024ca6d58aeaec_id_seq;
CREATE SEQUENCE "public".xc_6947ff28b66047d7924024ca6d58aeaec_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_6947ff28b66047d7924024ca6d58aeaec" (
    "id" integer DEFAULT nextval('xc_6947ff28b66047d7924024ca6d58aeaec_id_seq') NOT NULL,
    "site_id" integer,
    "site_root_id" integer,
    "blueprint_uuid" character varying(255),
    "content_group" character varying(255),
    "title" character varying(255),
    "slug" character varying(255),
    "is_enabled" boolean,
    "published_at" timestamp(0),
    "published_at_date" timestamp(0),
    "expired_at" timestamp(0),
    "draft_mode" integer DEFAULT '1' NOT NULL,
    "primary_id" integer,
    "primary_attrs" text,
    "is_version" boolean DEFAULT false NOT NULL,
    "avatar" text,
    "email" text,
    "role" text,
    "about" text,
    "created_user_id" integer,
    "updated_user_id" integer,
    "deleted_user_id" integer,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_6947ff28b66047d7924024ca6d58aeaec_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_6947ff28b66047d7924024ca6d58aeaec" IS 'Content for Author [Blog\\Author].';

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaec_site_id_index ON public.xc_6947ff28b66047d7924024ca6d58aeaec USING btree (site_id);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaec_site_root_id_index ON public.xc_6947ff28b66047d7924024ca6d58aeaec USING btree (site_root_id);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaec_blueprint_uuid_index ON public.xc_6947ff28b66047d7924024ca6d58aeaec USING btree (blueprint_uuid);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaec_content_group_index ON public.xc_6947ff28b66047d7924024ca6d58aeaec USING btree (content_group);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaec_slug_index ON public.xc_6947ff28b66047d7924024ca6d58aeaec USING btree (slug);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaec_primary_id_index ON public.xc_6947ff28b66047d7924024ca6d58aeaec USING btree (primary_id);


DROP TABLE IF EXISTS "xc_6947ff28b66047d7924024ca6d58aeaej";
CREATE TABLE "public"."xc_6947ff28b66047d7924024ca6d58aeaej" (
    "parent_id" integer,
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_6947ff28b66047d7924024ca6d58aeaej" IS 'Joins for Author [Blog\\Author].';

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaej_idx ON public.xc_6947ff28b66047d7924024ca6d58aeaej USING btree (parent_id, relation_type, field_name);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaej_field_name_index ON public.xc_6947ff28b66047d7924024ca6d58aeaej USING btree (field_name);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaej_site_id_index ON public.xc_6947ff28b66047d7924024ca6d58aeaej USING btree (site_id);


DROP TABLE IF EXISTS "xc_6947ff28b66047d7924024ca6d58aeaer";
DROP SEQUENCE IF EXISTS "public".xc_6947ff28b66047d7924024ca6d58aeaer_id_seq;
CREATE SEQUENCE "public".xc_6947ff28b66047d7924024ca6d58aeaer_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_6947ff28b66047d7924024ca6d58aeaer" (
    "id" integer DEFAULT nextval('xc_6947ff28b66047d7924024ca6d58aeaer_id_seq') NOT NULL,
    "host_id" integer,
    "host_field" character varying(255),
    "site_id" integer,
    "content_group" character varying(255),
    "content_value" text,
    "content_spawn_path" text,
    "parent_id" integer,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_6947ff28b66047d7924024ca6d58aeaer_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_6947ff28b66047d7924024ca6d58aeaer" IS 'Repeaters for Author [Blog\\Author].';

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaer_idx ON public.xc_6947ff28b66047d7924024ca6d58aeaer USING btree (host_id, host_field);

CREATE INDEX xc_6947ff28b66047d7924024ca6d58aeaer_site_id_index ON public.xc_6947ff28b66047d7924024ca6d58aeaer USING btree (site_id);


DROP TABLE IF EXISTS "xc_85e471d209b94f3da63b1ae9d92d2879c";
DROP SEQUENCE IF EXISTS "public".xc_85e471d209b94f3da63b1ae9d92d2879c_id_seq;
CREATE SEQUENCE "public".xc_85e471d209b94f3da63b1ae9d92d2879c_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_85e471d209b94f3da63b1ae9d92d2879c" (
    "id" integer DEFAULT nextval('xc_85e471d209b94f3da63b1ae9d92d2879c_id_seq') NOT NULL,
    "site_id" integer,
    "site_root_id" integer,
    "blueprint_uuid" character varying(255),
    "content_group" character varying(255),
    "title" character varying(255),
    "slug" character varying(255),
    "is_enabled" boolean,
    "published_at" timestamp(0),
    "published_at_date" timestamp(0),
    "expired_at" timestamp(0),
    "draft_mode" integer DEFAULT '1' NOT NULL,
    "primary_id" integer,
    "primary_attrs" text,
    "is_version" boolean DEFAULT false NOT NULL,
    "created_user_id" integer,
    "updated_user_id" integer,
    "deleted_user_id" integer,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_85e471d209b94f3da63b1ae9d92d2879c_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_85e471d209b94f3da63b1ae9d92d2879c" IS 'Content for Menu [Site\\Menus].';

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879c_site_id_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879c USING btree (site_id);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879c_site_root_id_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879c USING btree (site_root_id);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879c_blueprint_uuid_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879c USING btree (blueprint_uuid);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879c_content_group_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879c USING btree (content_group);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879c_slug_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879c USING btree (slug);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879c_primary_id_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879c USING btree (primary_id);


DROP TABLE IF EXISTS "xc_85e471d209b94f3da63b1ae9d92d2879j";
CREATE TABLE "public"."xc_85e471d209b94f3da63b1ae9d92d2879j" (
    "parent_id" integer,
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_85e471d209b94f3da63b1ae9d92d2879j" IS 'Joins for Menu [Site\\Menus].';

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879j_idx ON public.xc_85e471d209b94f3da63b1ae9d92d2879j USING btree (parent_id, relation_type, field_name);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879j_field_name_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879j USING btree (field_name);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879j_site_id_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879j USING btree (site_id);


DROP TABLE IF EXISTS "xc_85e471d209b94f3da63b1ae9d92d2879r";
DROP SEQUENCE IF EXISTS "public".xc_85e471d209b94f3da63b1ae9d92d2879r_id_seq;
CREATE SEQUENCE "public".xc_85e471d209b94f3da63b1ae9d92d2879r_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_85e471d209b94f3da63b1ae9d92d2879r" (
    "id" integer DEFAULT nextval('xc_85e471d209b94f3da63b1ae9d92d2879r_id_seq') NOT NULL,
    "host_id" integer,
    "host_field" character varying(255),
    "site_id" integer,
    "content_group" character varying(255),
    "content_value" text,
    "content_spawn_path" text,
    "parent_id" integer,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_85e471d209b94f3da63b1ae9d92d2879r_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_85e471d209b94f3da63b1ae9d92d2879r" IS 'Repeaters for Menu [Site\\Menus].';

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879r_idx ON public.xc_85e471d209b94f3da63b1ae9d92d2879r USING btree (host_id, host_field);

CREATE INDEX xc_85e471d209b94f3da63b1ae9d92d2879r_site_id_index ON public.xc_85e471d209b94f3da63b1ae9d92d2879r USING btree (site_id);


DROP TABLE IF EXISTS "xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c";
DROP SEQUENCE IF EXISTS "public".xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_id_seq;
CREATE SEQUENCE "public".xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c" (
    "id" integer DEFAULT nextval('xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_id_seq') NOT NULL,
    "site_id" integer,
    "site_root_id" integer,
    "blueprint_uuid" character varying(255),
    "content_group" character varying(255),
    "title" character varying(255),
    "slug" character varying(255),
    "is_enabled" boolean,
    "published_at" timestamp(0),
    "published_at_date" timestamp(0),
    "expired_at" timestamp(0),
    "draft_mode" integer DEFAULT '1' NOT NULL,
    "primary_id" integer,
    "primary_attrs" text,
    "is_version" boolean DEFAULT false NOT NULL,
    "created_user_id" integer,
    "updated_user_id" integer,
    "deleted_user_id" integer,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c" IS 'Content for About Page [Page\\About].';

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_site_id_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c USING btree (site_id);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_site_root_id_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c USING btree (site_root_id);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_blueprint_uuid_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c USING btree (blueprint_uuid);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_content_group_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c USING btree (content_group);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_slug_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c USING btree (slug);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c_primary_id_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1c USING btree (primary_id);


DROP TABLE IF EXISTS "xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j";
CREATE TABLE "public"."xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j" (
    "parent_id" integer,
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j" IS 'Joins for About Page [Page\\About].';

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j_idx ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j USING btree (parent_id, relation_type, field_name);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j_field_name_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j USING btree (field_name);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j_site_id_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1j USING btree (site_id);


DROP TABLE IF EXISTS "xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r";
DROP SEQUENCE IF EXISTS "public".xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r_id_seq;
CREATE SEQUENCE "public".xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r" (
    "id" integer DEFAULT nextval('xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r_id_seq') NOT NULL,
    "host_id" integer,
    "host_field" character varying(255),
    "site_id" integer,
    "content_group" character varying(255),
    "content_value" text,
    "content_spawn_path" text,
    "parent_id" integer,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r" IS 'Repeaters for About Page [Page\\About].';

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r_idx ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r USING btree (host_id, host_field);

CREATE INDEX xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r_site_id_index ON public.xc_a63fabaf7c0b4c74b36f7abf1a3ad1c1r USING btree (site_id);


DROP TABLE IF EXISTS "xc_b022a74b15e64c6b9eb917efc5103543c";
DROP SEQUENCE IF EXISTS "public".xc_b022a74b15e64c6b9eb917efc5103543c_id_seq;
CREATE SEQUENCE "public".xc_b022a74b15e64c6b9eb917efc5103543c_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_b022a74b15e64c6b9eb917efc5103543c" (
    "id" integer DEFAULT nextval('xc_b022a74b15e64c6b9eb917efc5103543c_id_seq') NOT NULL,
    "site_id" integer,
    "site_root_id" integer,
    "blueprint_uuid" character varying(255),
    "content_group" character varying(255),
    "title" character varying(255),
    "slug" character varying(255),
    "is_enabled" boolean,
    "published_at" timestamp(0),
    "published_at_date" timestamp(0),
    "expired_at" timestamp(0),
    "draft_mode" integer DEFAULT '1' NOT NULL,
    "primary_id" integer,
    "primary_attrs" text,
    "is_version" boolean DEFAULT false NOT NULL,
    "fullslug" character varying(255),
    "parent_id" integer,
    "nest_left" integer,
    "nest_right" integer,
    "nest_depth" integer,
    "description" text,
    "created_user_id" integer,
    "updated_user_id" integer,
    "deleted_user_id" integer,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_b022a74b15e64c6b9eb917efc5103543c_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_b022a74b15e64c6b9eb917efc5103543c" IS 'Content for Category [Blog\\Category].';

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543c_site_id_index ON public.xc_b022a74b15e64c6b9eb917efc5103543c USING btree (site_id);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543c_site_root_id_index ON public.xc_b022a74b15e64c6b9eb917efc5103543c USING btree (site_root_id);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543c_blueprint_uuid_index ON public.xc_b022a74b15e64c6b9eb917efc5103543c USING btree (blueprint_uuid);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543c_content_group_index ON public.xc_b022a74b15e64c6b9eb917efc5103543c USING btree (content_group);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543c_slug_index ON public.xc_b022a74b15e64c6b9eb917efc5103543c USING btree (slug);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543c_primary_id_index ON public.xc_b022a74b15e64c6b9eb917efc5103543c USING btree (primary_id);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543c_fullslug_index ON public.xc_b022a74b15e64c6b9eb917efc5103543c USING btree (fullslug);


DROP TABLE IF EXISTS "xc_b022a74b15e64c6b9eb917efc5103543j";
CREATE TABLE "public"."xc_b022a74b15e64c6b9eb917efc5103543j" (
    "parent_id" integer,
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_b022a74b15e64c6b9eb917efc5103543j" IS 'Joins for Category [Blog\\Category].';

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543j_idx ON public.xc_b022a74b15e64c6b9eb917efc5103543j USING btree (parent_id, relation_type, field_name);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543j_field_name_index ON public.xc_b022a74b15e64c6b9eb917efc5103543j USING btree (field_name);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543j_site_id_index ON public.xc_b022a74b15e64c6b9eb917efc5103543j USING btree (site_id);


DROP TABLE IF EXISTS "xc_b022a74b15e64c6b9eb917efc5103543r";
DROP SEQUENCE IF EXISTS "public".xc_b022a74b15e64c6b9eb917efc5103543r_id_seq;
CREATE SEQUENCE "public".xc_b022a74b15e64c6b9eb917efc5103543r_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_b022a74b15e64c6b9eb917efc5103543r" (
    "id" integer DEFAULT nextval('xc_b022a74b15e64c6b9eb917efc5103543r_id_seq') NOT NULL,
    "host_id" integer,
    "host_field" character varying(255),
    "site_id" integer,
    "content_group" character varying(255),
    "content_value" text,
    "content_spawn_path" text,
    "parent_id" integer,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_b022a74b15e64c6b9eb917efc5103543r_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_b022a74b15e64c6b9eb917efc5103543r" IS 'Repeaters for Category [Blog\\Category].';

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543r_idx ON public.xc_b022a74b15e64c6b9eb917efc5103543r USING btree (host_id, host_field);

CREATE INDEX xc_b022a74b15e64c6b9eb917efc5103543r_site_id_index ON public.xc_b022a74b15e64c6b9eb917efc5103543r USING btree (site_id);


DROP TABLE IF EXISTS "xc_edcd102e05254e4db07e633ae6c18db6c";
DROP SEQUENCE IF EXISTS "public".xc_edcd102e05254e4db07e633ae6c18db6c_id_seq;
CREATE SEQUENCE "public".xc_edcd102e05254e4db07e633ae6c18db6c_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_edcd102e05254e4db07e633ae6c18db6c" (
    "id" integer DEFAULT nextval('xc_edcd102e05254e4db07e633ae6c18db6c_id_seq') NOT NULL,
    "site_id" integer,
    "site_root_id" integer,
    "blueprint_uuid" character varying(255),
    "content_group" character varying(255),
    "title" character varying(255),
    "slug" character varying(255),
    "is_enabled" boolean,
    "published_at" timestamp(0),
    "published_at_date" timestamp(0),
    "expired_at" timestamp(0),
    "draft_mode" integer DEFAULT '1' NOT NULL,
    "primary_id" integer,
    "primary_attrs" text,
    "is_version" boolean DEFAULT false NOT NULL,
    "published_at_day" integer,
    "published_at_month" integer,
    "published_at_year" integer,
    "content" text,
    "author_id" integer,
    "featured_text" text,
    "gallery_media" text,
    "created_user_id" integer,
    "updated_user_id" integer,
    "deleted_user_id" integer,
    "deleted_at" timestamp(0),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_edcd102e05254e4db07e633ae6c18db6c_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_edcd102e05254e4db07e633ae6c18db6c" IS 'Content for Post [Blog\\Post].';

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6c_site_id_index ON public.xc_edcd102e05254e4db07e633ae6c18db6c USING btree (site_id);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6c_site_root_id_index ON public.xc_edcd102e05254e4db07e633ae6c18db6c USING btree (site_root_id);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6c_blueprint_uuid_index ON public.xc_edcd102e05254e4db07e633ae6c18db6c USING btree (blueprint_uuid);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6c_content_group_index ON public.xc_edcd102e05254e4db07e633ae6c18db6c USING btree (content_group);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6c_slug_index ON public.xc_edcd102e05254e4db07e633ae6c18db6c USING btree (slug);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6c_primary_id_index ON public.xc_edcd102e05254e4db07e633ae6c18db6c USING btree (primary_id);


DROP TABLE IF EXISTS "xc_edcd102e05254e4db07e633ae6c18db6j";
CREATE TABLE "public"."xc_edcd102e05254e4db07e633ae6c18db6j" (
    "parent_id" integer,
    "relation_id" integer,
    "relation_type" character varying(255),
    "field_name" character varying(255),
    "site_id" integer
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_edcd102e05254e4db07e633ae6c18db6j" IS 'Joins for Post [Blog\\Post].';

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6j_idx ON public.xc_edcd102e05254e4db07e633ae6c18db6j USING btree (parent_id, relation_type, field_name);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6j_field_name_index ON public.xc_edcd102e05254e4db07e633ae6c18db6j USING btree (field_name);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6j_site_id_index ON public.xc_edcd102e05254e4db07e633ae6c18db6j USING btree (site_id);


DROP TABLE IF EXISTS "xc_edcd102e05254e4db07e633ae6c18db6r";
DROP SEQUENCE IF EXISTS "public".xc_edcd102e05254e4db07e633ae6c18db6r_id_seq;
CREATE SEQUENCE "public".xc_edcd102e05254e4db07e633ae6c18db6r_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."xc_edcd102e05254e4db07e633ae6c18db6r" (
    "id" integer DEFAULT nextval('xc_edcd102e05254e4db07e633ae6c18db6r_id_seq') NOT NULL,
    "host_id" integer,
    "host_field" character varying(255),
    "site_id" integer,
    "content_group" character varying(255),
    "content_value" text,
    "content_spawn_path" text,
    "parent_id" integer,
    "sort_order" integer,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "xc_edcd102e05254e4db07e633ae6c18db6r_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

COMMENT ON TABLE "public"."xc_edcd102e05254e4db07e633ae6c18db6r" IS 'Repeaters for Post [Blog\\Post].';

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6r_idx ON public.xc_edcd102e05254e4db07e633ae6c18db6r USING btree (host_id, host_field);

CREATE INDEX xc_edcd102e05254e4db07e633ae6c18db6r_site_id_index ON public.xc_edcd102e05254e4db07e633ae6c18db6r USING btree (site_id);


-- 2026-04-28 15:33:43 UTC
